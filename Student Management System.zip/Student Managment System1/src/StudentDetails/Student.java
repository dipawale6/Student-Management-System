package StudentDetails;

import java.util.Scanner;

public class Student {
	private String FirstName;
	private String LastName;
	private String EmailId;
	private int PhoneNo;
	private String Address;
	private int Year;
	private String Courses=" ";
	private int Balance;
	private int StudentID;
	private static int CostOfCourse = 600;
	
	Scanner sc = new Scanner(System.in);

	public Student() {
		System.out.println("Enter student First Name : ");
		this.FirstName = sc.nextLine();

		System.out.println("Enter student Last Name : ");
		this.LastName = sc.nextLine();

		System.out.println("\nEnter student Address :");
		this.Address = sc.nextLine();

		System.out.println("Enter student ID :");
		this.StudentID = sc.nextInt();

		System.out.println("Enter student Phone No :");
		this.PhoneNo = sc.nextInt();

		System.out.println("\nEnter student Email Id :");
		this.EmailId = sc.next();

	}

	public void course()
	{
		int i = 1;
		System.out.println(" Year of Student");
		System.out.println("1 -FirstYear\n2 -SecondYear\n3 -ThirdYear\n4 -FifthYear \nEnter the year of student ");
		this.Year = sc.nextInt();
		System.out.println("how many course enroll: ");
	
		int coursecount = sc.nextInt();

		do {
			System.out.println("Enter Course name : ");
			
			String course = sc.next();
			if (!course.equals("q")) {
				Courses = Courses + "\n " + course;

				Balance = Balance + CostOfCourse;
			} else {
				break;
			}
			i++;
		} while (i <= coursecount);
	}

	public void viewBalance() {
		System.out.println("\nYour Balance is: $" + Balance);
	}

	public void payTution() {
		viewBalance();
		System.out.print("\nEnter Your Payment: $");
		int payment = sc.nextInt();

		Balance = Balance - payment;
		System.out.println("\nThank you for your payment of $" + payment);

		viewBalance();
	}

	public String toString() {
		return "\nName: " + FirstName + " " + LastName +

				"\nAddress: " + Address +

				"\nStudent ID: " + StudentID +

				"\nPhoneNo: " + PhoneNo +

				"\nEmail Id: " + EmailId +

				"\nCourses Enrolled: " + Courses +

				"\nBalance: $ " + Balance;
	}
}
