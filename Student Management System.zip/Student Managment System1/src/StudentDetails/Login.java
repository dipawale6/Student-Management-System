package StudentDetails;

import java.util.Scanner;

public class Login extends TestStudent {
	public void log() {
		Scanner sc = new Scanner(System.in);
		System.out.println("\n***************WELCOME to login page******************** ");
		System.out.println("\nEnter user name :");
		String userName = sc.next();
		System.out.println("Enter user password : ");
		int password = sc.nextInt();
		System.out.println(userName + " successfully login......... ");
	}
}