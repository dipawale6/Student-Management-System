package StudentDetails;

import java.util.Scanner;

public class TestStudent {

	public static void main(String[] args)
	{
		Registration reg = new Registration();
		reg.setFirstName();
		reg.setLastName();
		reg.setUserName();
		reg.setEmailId();
		reg.setPassword();
        reg.setPhoneNo();
        
		Scanner sc = new Scanner(System.in);

			System.out.println("FirstName : " +reg.getFirstName());
			System.out.println("LastName : " + reg.getLastName());
			System.out.println("UserName : " + reg.getUserName());
			System.out.println("EmailId : " +reg.getEmailId());
			System.out.println("Password : " +reg.getPassword());
			System.out.println("PhoneNo : "+reg.getPhoneNo());
			
		Login l = new Login();
		l.log();

		Student stud  = new Student();

		System.out.println("Enter Number Of New Student To Enroll:");
	
		int numOfStudents = sc.nextInt();
		Student[] students = new Student[numOfStudents];

		for (int n = 0; n < numOfStudents; n++) {
			students[n] = new Student();
			students[n].course();
			students[n].payTution();

			System.out.println(students[n].toString());
		}

	}

}

