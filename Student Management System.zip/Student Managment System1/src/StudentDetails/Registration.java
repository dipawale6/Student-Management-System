package StudentDetails;

import java.util.Scanner;

public class Registration extends TestStudent {
	private String FirstName;
	private String LastName;
	private String UserName;
	private String Password;
	private String EmailId;
	private int PhoneNo;
	
	Scanner sc = new Scanner(System.in);

	public String getFirstName() 
	{
		return FirstName;
	}

	public void setFirstName() 
	{

		System.out.println("Enter First name: ");
		FirstName=sc.next();
	}

	public String getLastName() 
	{
		return LastName;
	}

	public void setLastName()
	{

		System.out.println("Enter Last name: ");
		LastName=sc.next();

	}

	public String getUserName() 
	{
		return UserName;
	}

	public void setUserName() 
	{
	
		System.out.println("Enter userName: ");
		UserName=sc.next();
	}

	public  String getEmailId()
    {
		return EmailId;
	}

	public void setEmailId() 
	{

		System.out.println("Enter EmailId: ");
		EmailId=sc.next();
		
	}
	public String getPassword() 
	{
		return Password;
	}
	public void setPassword()
	{
		System.out.println("Enter Password: ");
		Password=sc.next();
	}

	public long getPhoneNo() 
	{
		return PhoneNo;
	}

	public void setPhoneNo() 
	{
	
		System.out.println("Enter PhoneNo: ");
		PhoneNo=sc.nextInt();

	}

	@Override
	public String toString() 
	{
		return "Register [firstName=" + FirstName + ", lastName=" + LastName + ", password=" + Password + ", emailId="
				+ EmailId + ", phoneNo=" + PhoneNo + "]";
	}

		
	}

